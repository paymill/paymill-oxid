<?php
$sLangName  = "Deutsch";
$aLang = array(
    'PAYMILL_VALIDATION_CARDNUMBER' => 'Bitt geben Sie eine g&uuml;ltige Kartennummer ein.',
    'PAYMILL_VALIDATION_EXP' => 'Bitte geben Sie ein in der Zukunft liegendes G&uuml;ltigkeitsdatum ein.',
    'PAYMILL_VALIDATION_CVC' => 'Bitte geben Sie einen g&uuml;ltigen CVC-Code ein.',
    'PAYMILL_VALIDATION_CARDHOLDER' => 'Bitte geben Sie den Karteninhaber ein',
    'charset' => 'UTF-8',
    'PAYMILL_POWERED_TEXT' => 'Sichere Kreditkartenzahlung powered by',
    'PAYMILL_ELV_POWERED_TEXT' => 'Sicheres Lastschriftverfahren powered by'
);
?>